//
//  ViewController.m
//  Js调用微信App支付
//
//  Created by sunsoft on 15/10/28.
//  Copyright © 2015年 sunnsoft. All rights reserved.
//

#import "ViewController.h"
#import "TestBridge.h"


@interface ViewController ()

@property (nonatomic) TestBridge* bridge;
@property(nonatomic,strong)UIWebView * webview;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _webview = [[UIWebView alloc] initWithFrame:self.view.bounds];
    _bridge = [TestBridge bridgeForWebView:_webview webViewDelegate:self];
    //test only
    
    
    NSURL *url =[[NSURL alloc] initWithString:@"http://112.74.206.25:11133/webview_js/webview_js.do"];
    NSURLRequest *request =  [[NSURLRequest alloc] initWithURL:url];
    [_webview loadRequest:request];
    [self.view addSubview:_webview];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
