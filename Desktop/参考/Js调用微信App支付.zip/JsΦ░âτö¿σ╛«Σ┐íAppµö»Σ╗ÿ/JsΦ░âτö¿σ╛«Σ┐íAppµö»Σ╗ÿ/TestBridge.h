//
//  TestBridge.h
//  WebViewJsBridge
//
//  Created by zhaoxy on 14-4-2.
//  Copyright (c) 2014年 tsinghua. All rights reserved.
//

#import "WebViewJsBridge.h"
#import "WXApi.h"
#import "WXApiObject.h"
//APP端签名相关头文件
#import "payRequsestHandler.h"
//服务端签名只需要用到下面一个头文件
//#import "ApiXml.h"
#import <QuartzCore/QuartzCore.h>



@interface TestBridge : WebViewJsBridge

- (void)sendPay;


@end
