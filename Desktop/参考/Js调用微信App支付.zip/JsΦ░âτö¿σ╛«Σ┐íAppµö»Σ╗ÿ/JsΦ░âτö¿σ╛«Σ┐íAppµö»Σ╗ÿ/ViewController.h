//
//  ViewController.h
//  Js调用微信App支付
//
//  Created by sunsoft on 15/10/28.
//  Copyright © 2015年 sunnsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIWebViewDelegate>


@end

